from operator import truediv


def EsPar(numero):
    if (numero % 2) == 0:
        return True
    else:
        return False