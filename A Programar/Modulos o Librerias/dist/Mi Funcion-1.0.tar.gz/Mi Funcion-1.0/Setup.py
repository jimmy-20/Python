from setuptools import setup

setup(
    name="Mi Funcion",
    version="1.0",
    description="Verifica si el numero es par",
    author="Jimmy A.",
    author_email="jasocanal@gmail.com",
    packages=["Paquetes"]
)